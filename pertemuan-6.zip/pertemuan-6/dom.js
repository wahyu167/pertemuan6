document.write("Halo..");

document.writeln("<br/>Halo.. dari baris kedua..");

document.writeln("<br/><div id='baris3' style='padding: 2em; color: white; background: black;'>Halo.. dari baris ke-3..</div>");

document.writeln("<br/><div id='baris4' style='padding: 1em; color: white; background: pink;'>Halo.. dari baris ke-4..</div>");

document.title = "Judul";
'Judul';

document.body.style.backgroundImage = "linear-gradient(to right bottom, red, white)";

document.body.style.backgroundRepeat = "no-repeat";

document.title.length;

document.title = "Halo Dunia";

document.title.length;

document.head;

